package com.example.kronometreplus

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView

class MainActivity : android.app.Activity() {
    private lateinit var timeText: TextView
    private lateinit var statusText: TextView
    private lateinit var startPauseButton: Button
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("stopwatch", MODE_PRIVATE) }

    private val ticker = object : Runnable {
        override fun run() {
            val running = prefs.getBoolean("running", false)
            val elapsed = prefs.getLong("elapsed", 0L) +
                if (running) (android.os.SystemClock.elapsedRealtime() -
                    prefs.getLong("base", android.os.SystemClock.elapsedRealtime())) else 0L
            timeText.text = formatTime(elapsed)
            statusText.text = if (running) "Çalışıyor" else if (elapsed > 0) "Duraklatıldı" else "Hazır"
            startPauseButton.text = if (running) "Durdur" else if (elapsed > 0) "Devam et" else "Başlat"
            handler.postDelayed(this, 100)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        timeText = findViewById(R.id.timeText)
        statusText = findViewById(R.id.statusText)
        startPauseButton = findViewById(R.id.startPauseButton)
        findViewById<Button>(R.id.resetButton).setOnClickListener { sendAction(StopwatchService.ACTION_RESET) }
        startPauseButton.setOnClickListener {
            val running = prefs.getBoolean("running", false)
            sendAction(if (running) StopwatchService.ACTION_PAUSE else StopwatchService.ACTION_START)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun sendAction(action: String) {
        val intent = Intent(this, StopwatchService::class.java).setAction(action)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
    }

    override fun onResume() { super.onResume(); handler.post(ticker) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }

    private fun formatTime(ms: Long): String {
        val total = ms / 1000
        return String.format("%02d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60)
    }
}

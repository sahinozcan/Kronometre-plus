package com.example.kronometreplus

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.SystemClock

class StopwatchService : Service() {
    private val prefs by lazy { getSharedPreferences("stopwatch", MODE_PRIVATE) }
    private val channelId = "stopwatch_channel"

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startTimer()
            ACTION_PAUSE -> pauseTimer()
            ACTION_RESET -> resetTimer()
        }
        startForeground(NOTIFICATION_ID, buildNotification())
        return START_STICKY
    }

    private fun startTimer() {
        if (!prefs.getBoolean("running", false)) {
            prefs.edit().putLong("base", SystemClock.elapsedRealtime()).putBoolean("running", true).apply()
        }
    }

    private fun pauseTimer() {
        if (prefs.getBoolean("running", false)) {
            val elapsed = prefs.getLong("elapsed", 0L) +
                (SystemClock.elapsedRealtime() - prefs.getLong("base", SystemClock.elapsedRealtime()))
            prefs.edit().putLong("elapsed", elapsed).putBoolean("running", false).apply()
        }
    }

    private fun resetTimer() {
        prefs.edit().putLong("elapsed", 0L).putBoolean("running", false).apply()
    }

    private fun buildNotification(): Notification {
        val running = prefs.getBoolean("running", false)
        val elapsed = prefs.getLong("elapsed", 0L) +
            if (running) (SystemClock.elapsedRealtime() - prefs.getLong("base", SystemClock.elapsedRealtime())) else 0L
        val openApp = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val action = if (running) ACTION_PAUSE else ACTION_START
        val actionLabel = if (running) "Durdur" else "Devam et"
        val actionIntent = PendingIntent.getService(
            this, 2, Intent(this, StopwatchService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = Notification.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Kronometre+")
            .setContentText(if (running) "Kronometre çalışıyor" else "Kronometre duraklatıldı")
            .setContentIntent(openApp)
            .setOngoing(running)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, actionLabel, actionIntent)

        if (running) {
            builder.setUsesChronometer(true)
                .setWhen(System.currentTimeMillis() - elapsed)
        } else {
            builder.setUsesChronometer(false)
                .setContentText("Geçen süre: ${formatTime(elapsed)}")
        }
        return builder.build()
    }

    private fun formatTime(ms: Long): String {
        val s = ms / 1000
        return String.format("%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Kronometre", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.example.kronometreplus.START"
        const val ACTION_PAUSE = "com.example.kronometreplus.PAUSE"
        const val ACTION_RESET = "com.example.kronometreplus.RESET"
        const val NOTIFICATION_ID = 7
    }
}

KRONOMETRE+ - başlangıç Android projesi

Bu klasör Android Studio ile açılacak bir Kotlin/Android proje iskeletidir.
Henüz derlenmiş APK değildir ve gerçek Lenovo Tab M9 üzerinde test edilmemiştir.

Özellikler:
- Siyah arayüz ve turkuaz vurgu
- Başlat / durdur / devam et / sıfırla
- Ekran kilitliyken devam etmesi için foreground service
- Kilit ekranı bildiriminde sistem kronometresi ve Durdur/Devam et eylemi

APK oluşturmak için:
1. Android Studio'yu bir bilgisayara kurun.
2. Bu ZIP dosyasını çıkarın.
3. Android Studio > Open ile KronometrePlus klasörünü açın.
4. Gradle eşitlemesi tamamlandıktan sonra Build > Build APK(s) seçin.
5. İlk denemeyi kendi tabletinizde yapın; bildirim izni verin.

Not:
Android 13 ve üzeri sürümlerde bildirim izni gerekir. Bazı üretici kilit ekranları bildirim
içeriğini gizleyebilir; Lenovo ayarlarında kilit ekranı bildirimlerinin gösterilmesine izin verin.
Android 14+ özel foreground service türü ve Android 16 hedef sürüm davranışları nedeniyle
proje Android Studio'da derlenip gerçek cihazda test edilmelidir. Google Play'e yayımlama
ayrı gereklilikler içerebilir.


TABLETTEN BULUTTA APK DERLEME (GitHub Actions):
1. GitHub hesabı açın veya hesabınıza giriş yapın.
2. New repository ile boş bir depo oluşturun (ör. KronometrePlus).
3. Bu ZIP içindeki dosyaları depoya yükleyin; .github klasörü dahil olmalı.
4. Depoda Actions sekmesini açın.
5. "Build KronometrePlus APK" iş akışını seçip "Run workflow" düğmesine dokunun.
6. İşlem tamamlanınca çalışmanın altındaki Artifacts bölümünden
   KronometrePlus-debug-apk dosyasını indirin.
7. ZIP içinden app-debug.apk dosyasını çıkarıp tablette açın.

Not: GitHub arayüzündeki menü adları zamanla değişebilir. Bu, test amaçlı imzalı olmayan
debug APK üretir. İlk kurulumda Android bilinmeyen uygulama kaynağı izni isteyebilir.
Yalnızca kendi oluşturduğunuz depodaki çıktıyı kurun. Gerçek cihaz testi şarttır.
